package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val isAnnouncerEnabled: Boolean = true,
    val isDrivingModeEnabled: Boolean = false,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val speechVolume: Float = 1.0f,
    val announcementTemplate: String = "{name} is calling you",
    val repeatCount: Int = 2,
    val delaySeconds: Int = 1,
    val announceUnknownNumbers: Boolean = true,
    val autoRejectInDrivingMode: Boolean = false,
    val autoSmsInDrivingMode: Boolean = true,
    val quickReplyMessage: String = "I am currently driving. I'll call you back shortly.",
    val highContrastMode: Boolean = false,
    val hapticFeedbackEnabled: Boolean = true,
    val announceInSilentMode: Boolean = true,
    val isWhitelistEnabled: Boolean = false,
    val whitelistedContacts: Set<String> = setOf("+91 98765 43210", "Rahul", "Family", "Doctor"),
    val ttsLanguageCode: String = "en_US"
)

class AppPreferencesRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("caller_announcer_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        return AppSettings(
            isAnnouncerEnabled = prefs.getBoolean("isAnnouncerEnabled", true),
            isDrivingModeEnabled = prefs.getBoolean("isDrivingModeEnabled", false),
            speechRate = prefs.getFloat("speechRate", 1.0f),
            speechPitch = prefs.getFloat("speechPitch", 1.0f),
            speechVolume = prefs.getFloat("speechVolume", 1.0f),
            announcementTemplate = prefs.getString("announcementTemplate", "{name} is calling you") ?: "{name} is calling you",
            repeatCount = prefs.getInt("repeatCount", 2),
            delaySeconds = prefs.getInt("delaySeconds", 1),
            announceUnknownNumbers = prefs.getBoolean("announceUnknownNumbers", true),
            autoRejectInDrivingMode = prefs.getBoolean("autoRejectInDrivingMode", false),
            autoSmsInDrivingMode = prefs.getBoolean("autoSmsInDrivingMode", true),
            quickReplyMessage = prefs.getString("quickReplyMessage", "I am currently driving. I'll call you back shortly.") ?: "I am currently driving. I'll call you back shortly.",
            highContrastMode = prefs.getBoolean("highContrastMode", false),
            hapticFeedbackEnabled = prefs.getBoolean("hapticFeedbackEnabled", true),
            announceInSilentMode = prefs.getBoolean("announceInSilentMode", true),
            isWhitelistEnabled = prefs.getBoolean("isWhitelistEnabled", false),
            whitelistedContacts = prefs.getStringSet("whitelistedContacts", setOf("+91 98765 43210", "Rahul", "Family", "Doctor")) ?: setOf("+91 98765 43210", "Rahul", "Family", "Doctor"),
            ttsLanguageCode = prefs.getString("ttsLanguageCode", "en_US") ?: "en_US"
        )
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val newSettings = transform(_settings.value)
        _settings.value = newSettings

        prefs.edit()
            .putBoolean("isAnnouncerEnabled", newSettings.isAnnouncerEnabled)
            .putBoolean("isDrivingModeEnabled", newSettings.isDrivingModeEnabled)
            .putFloat("speechRate", newSettings.speechRate)
            .putFloat("speechPitch", newSettings.speechPitch)
            .putFloat("speechVolume", newSettings.speechVolume)
            .putString("announcementTemplate", newSettings.announcementTemplate)
            .putInt("repeatCount", newSettings.repeatCount)
            .putInt("delaySeconds", newSettings.delaySeconds)
            .putBoolean("announceUnknownNumbers", newSettings.announceUnknownNumbers)
            .putBoolean("autoRejectInDrivingMode", newSettings.autoRejectInDrivingMode)
            .putBoolean("autoSmsInDrivingMode", newSettings.autoSmsInDrivingMode)
            .putString("quickReplyMessage", newSettings.quickReplyMessage)
            .putBoolean("highContrastMode", newSettings.highContrastMode)
            .putBoolean("hapticFeedbackEnabled", newSettings.hapticFeedbackEnabled)
            .putBoolean("announceInSilentMode", newSettings.announceInSilentMode)
            .putBoolean("isWhitelistEnabled", newSettings.isWhitelistEnabled)
            .putStringSet("whitelistedContacts", newSettings.whitelistedContacts)
            .putString("ttsLanguageCode", newSettings.ttsLanguageCode)
            .apply()
    }
}
