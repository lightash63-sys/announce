package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "announced_calls")
data class AnnouncedCall(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val callerName: String,
    val phoneNumber: String,
    val timestamp: Long = System.currentTimeMillis(),
    val announcedText: String,
    val isContactFound: Boolean,
    val actionTaken: String = "Announced", // "Announced", "Auto-Rejected", "Quick Reply Sent"
    val isSimulated: Boolean = false
)
