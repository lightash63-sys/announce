package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.AnnouncedCall
import kotlinx.coroutines.flow.Flow

@Dao
interface CallHistoryDao {

    @Query("SELECT * FROM announced_calls ORDER BY timestamp DESC")
    fun getAllAnnouncedCalls(): Flow<List<AnnouncedCall>>

    @Query("SELECT * FROM announced_calls ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentCalls(limit: Int = 10): Flow<List<AnnouncedCall>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCall(call: AnnouncedCall): Long

    @Query("DELETE FROM announced_calls WHERE id = :id")
    suspend fun deleteCallById(id: Long)

    @Query("DELETE FROM announced_calls")
    suspend fun clearAllHistory()
}
