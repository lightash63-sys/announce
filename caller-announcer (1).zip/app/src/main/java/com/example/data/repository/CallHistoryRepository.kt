package com.example.data.repository

import com.example.data.db.CallHistoryDao
import com.example.data.model.AnnouncedCall
import kotlinx.coroutines.flow.Flow

class CallHistoryRepository(private val dao: CallHistoryDao) {

    val allCalls: Flow<List<AnnouncedCall>> = dao.getAllAnnouncedCalls()

    fun getRecentCalls(limit: Int = 5): Flow<List<AnnouncedCall>> = dao.getRecentCalls(limit)

    suspend fun logCall(call: AnnouncedCall): Long = dao.insertCall(call)

    suspend fun deleteCall(id: Long) = dao.deleteCallById(id)

    suspend fun clearHistory() = dao.clearAllHistory()
}
