package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.telephony.SmsManager
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.AnnouncedCall
import com.example.data.preferences.AppPreferencesRepository
import com.example.data.preferences.AppSettings
import com.example.data.repository.CallHistoryRepository
import com.example.service.TtsManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepository = AppPreferencesRepository(application)
    private val callHistoryRepository = CallHistoryRepository(
        AppDatabase.getDatabase(application).callHistoryDao()
    )
    val ttsManager = TtsManager(application)

    val settings: StateFlow<AppSettings> = prefsRepository.settings

    val callHistory: StateFlow<List<AnnouncedCall>> = callHistoryRepository.allCalls
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val isSpeaking: StateFlow<Boolean> = ttsManager.isSpeaking
    val ttsStatus: StateFlow<String> = ttsManager.ttsStatus

    private val _simulatedCallActive = MutableStateFlow(false)
    val simulatedCallActive: StateFlow<Boolean> = _simulatedCallActive.asStateFlow()

    private val _activeSimulatedCall = MutableStateFlow<AnnouncedCall?>(null)
    val activeSimulatedCall: StateFlow<AnnouncedCall?> = _activeSimulatedCall.asStateFlow()

    fun toggleAnnouncer(enabled: Boolean) {
        prefsRepository.updateSettings { it.copy(isAnnouncerEnabled = enabled) }
        triggerHaptic()
    }

    fun toggleDrivingMode(enabled: Boolean) {
        prefsRepository.updateSettings { it.copy(isDrivingModeEnabled = enabled) }
        triggerHaptic()
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        prefsRepository.updateSettings(transform)
    }

    fun toggleWhitelistMode(enabled: Boolean) {
        prefsRepository.updateSettings { it.copy(isWhitelistEnabled = enabled) }
        triggerHaptic()
    }

    fun addWhitelistContact(contact: String) {
        if (contact.isBlank()) return
        val currentSet = settings.value.whitelistedContacts.toMutableSet()
        currentSet.add(contact.trim())
        prefsRepository.updateSettings { it.copy(whitelistedContacts = currentSet) }
        triggerHaptic()
    }

    fun removeWhitelistContact(contact: String) {
        val currentSet = settings.value.whitelistedContacts.toMutableSet()
        currentSet.remove(contact)
        prefsRepository.updateSettings { it.copy(whitelistedContacts = currentSet) }
        triggerHaptic()
    }

    fun updateLanguage(languageCode: String) {
        prefsRepository.updateSettings { it.copy(ttsLanguageCode = languageCode) }
        ttsManager.setLanguage(languageCode)
        triggerHaptic()
    }

    fun testTtsPreview(sampleText: String? = null) {
        val currentSettings = settings.value
        val textToSpeak = sampleText ?: currentSettings.announcementTemplate.replace("{name}", "Rahul")
        ttsManager.speak(
            text = textToSpeak,
            speechRate = currentSettings.speechRate,
            speechPitch = currentSettings.speechPitch,
            speechVolume = currentSettings.speechVolume,
            repeatCount = currentSettings.repeatCount,
            delayMs = currentSettings.delaySeconds * 1000L,
            languageCode = currentSettings.ttsLanguageCode
        )
        triggerHaptic()
    }

    fun stopTts() {
        ttsManager.stop()
        _simulatedCallActive.value = false
        _activeSimulatedCall.value = null
        triggerHaptic()
    }

    /**
     * Simulates an incoming call event for interactive testing, emulator usage, or blind accessibility preview.
     */
    fun simulateIncomingCall(callerName: String, phoneNumber: String, isContactFound: Boolean = true) {
        val currentSettings = settings.value

        // Check whitelist filtering
        if (currentSettings.isWhitelistEnabled) {
            val cleanIncoming = phoneNumber.replace(Regex("[^0-9+]"), "")
            val isWhitelisted = currentSettings.whitelistedContacts.any { entry ->
                val cleanEntry = entry.replace(Regex("[^0-9+]"), "")
                (cleanEntry.isNotEmpty() && cleanIncoming.endsWith(cleanEntry)) ||
                        callerName.contains(entry, ignoreCase = true) ||
                        entry.contains(callerName, ignoreCase = true)
            }

            if (!isWhitelisted) {
                val blockedCall = AnnouncedCall(
                    callerName = callerName,
                    phoneNumber = phoneNumber,
                    announcedText = "Blocked by Whitelist Filter",
                    isContactFound = isContactFound,
                    actionTaken = "Blocked (Not Whitelisted)",
                    isSimulated = true
                )
                _activeSimulatedCall.value = blockedCall
                _simulatedCallActive.value = true
                viewModelScope.launch {
                    callHistoryRepository.logCall(blockedCall)
                }
                triggerHaptic()
                return
            }
        }

        val announcedText = currentSettings.announcementTemplate.replace("{name}", callerName)

        var actionTaken = "Announced (Test)"

        if (currentSettings.isDrivingModeEnabled && currentSettings.autoSmsInDrivingMode) {
            actionTaken = "Quick Reply SMS Sent"
        } else if (currentSettings.isDrivingModeEnabled && currentSettings.autoRejectInDrivingMode) {
            actionTaken = "Auto-Rejected Call"
        }

        val callItem = AnnouncedCall(
            callerName = callerName,
            phoneNumber = phoneNumber,
            announcedText = announcedText,
            isContactFound = isContactFound,
            actionTaken = actionTaken,
            isSimulated = true
        )

        _activeSimulatedCall.value = callItem
        _simulatedCallActive.value = true

        // Perform TTS announcement
        ttsManager.speak(
            text = announcedText,
            speechRate = currentSettings.speechRate,
            speechPitch = currentSettings.speechPitch,
            speechVolume = currentSettings.speechVolume,
            repeatCount = currentSettings.repeatCount,
            delayMs = currentSettings.delaySeconds * 1000L,
            languageCode = currentSettings.ttsLanguageCode
        )

        triggerHaptic()

        // Log call in Room DB
        viewModelScope.launch {
            callHistoryRepository.logCall(callItem)
        }
    }

    fun deleteCall(id: Long) {
        viewModelScope.launch {
            callHistoryRepository.deleteCall(id)
        }
        triggerHaptic()
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            callHistoryRepository.clearHistory()
        }
        triggerHaptic()
    }

    fun triggerHaptic() {
        if (!settings.value.hapticFeedbackEnabled) return
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator.vibrate(
                    VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(30)
                }
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Haptic feedback error", e)
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
    }
}
