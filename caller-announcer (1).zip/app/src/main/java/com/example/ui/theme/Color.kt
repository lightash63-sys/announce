package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Vibrant Theme Colors
val BluePrimary = Color(0xFF0284C7)
val BluePrimaryContainer = Color(0xFFE0F2FE)
val CyanAccent = Color(0xFF06B6D4)

val EmeraldActive = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)

val AmberDriving = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)

val CrimsonDanger = Color(0xFFEF4444)
val SlateBackground = Color(0xFF0F172A)
val SlateSurface = Color(0xFF1E293B)

// High Contrast Theme Colors (for accessibility)
val HighContrastPrimary = Color(0xFFFFD700) // Vibrant Gold
val HighContrastBackground = Color(0xFF000000) // Pure Black
val HighContrastSurface = Color(0xFF1A1A1A)
val HighContrastText = Color(0xFFFFFFFF)
val HighContrastAccent = Color(0xFF00FFFF)

