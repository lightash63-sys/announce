package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp

data class PresetCaller(val name: String, val number: String, val isKnown: Boolean)

val DEFAULT_PRESETS = listOf(
    PresetCaller("Rahul", "+91 98765 43210", true),
    PresetCaller("Mom", "+1 555 019 2831", true),
    PresetCaller("Boss (Office)", "+1 555 012 9940", true),
    PresetCaller("Unknown Number", "+1 800 555 0199", false)
)

@Composable
fun CallSimulatorDialog(
    onDismiss: () -> Unit,
    onSimulate: (callerName: String, phoneNumber: String, isKnown: Boolean) -> Unit
) {
    var nameInput by remember { mutableStateOf("Rahul") }
    var numberInput by remember { mutableStateOf("+91 98765 43210") }
    var isKnownState by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text("Simulate Incoming Call")
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Test how the app announces callers out loud without needing a second phone:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Quick Presets:", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    DEFAULT_PRESETS.take(2).forEach { preset ->
                        FilterChip(
                            selected = nameInput == preset.name,
                            onClick = {
                                nameInput = preset.name
                                numberInput = preset.number
                                isKnownState = preset.isKnown
                            },
                            label = { Text(preset.name) },
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    DEFAULT_PRESETS.drop(2).forEach { preset ->
                        FilterChip(
                            selected = nameInput == preset.name,
                            onClick = {
                                nameInput = preset.name
                                numberInput = preset.number
                                isKnownState = preset.isKnown
                            },
                            label = { Text(preset.name) },
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Caller Contact Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sim_name_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = numberInput,
                    onValueChange = { numberInput = it },
                    label = { Text("Phone Number") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sim_number_input"),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSimulate(nameInput, numberInput, isKnownState)
                    onDismiss()
                },
                modifier = Modifier
                    .height(48.dp)
                    .testTag("confirm_simulate_btn")
            ) {
                Icon(Icons.Default.Call, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Simulate Call")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.height(48.dp)
            ) {
                Text("Cancel")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
