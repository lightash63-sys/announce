package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.MainViewModel

val FORMAT_PRESETS = listOf(
    "{name} is calling you",
    "Incoming call from {name}",
    "Attention: {name} is calling",
    "Call from {name}"
)

data class TtsLanguage(val displayName: String, val code: String)

val SUPPORTED_LANGUAGES = listOf(
    TtsLanguage("English (US)", "en_US"),
    TtsLanguage("English (UK)", "en_GB"),
    TtsLanguage("Spanish (Spain)", "es_ES"),
    TtsLanguage("French (France)", "fr_FR"),
    TtsLanguage("German (Germany)", "de_DE"),
    TtsLanguage("Hindi (India)", "hi_IN"),
    TtsLanguage("Japanese (Japan)", "ja_JP"),
    TtsLanguage("Portuguese (Brazil)", "pt_BR")
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TtsSettingsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var templateText by remember(settings.announcementTemplate) { mutableStateOf(settings.announcementTemplate) }
    var languageExpanded by remember { mutableStateOf(false) }
    var newWhitelistContactText by remember { mutableStateOf("") }

    val currentLanguage = SUPPORTED_LANGUAGES.find { it.code == settings.ttsLanguageCode }
        ?: SUPPORTED_LANGUAGES[0]

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Voice & Speech Settings",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // TTS Language Dropdown Menu Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Text-To-Speech Language",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Announce caller names correctly across multiple languages",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        ExposedDropdownMenuBox(
                            expanded = languageExpanded,
                            onExpandedChange = { languageExpanded = !languageExpanded },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = currentLanguage.displayName,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Speech Language Engine") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = languageExpanded) },
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                                    .testTag("language_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = languageExpanded,
                                onDismissRequest = { languageExpanded = false }
                            ) {
                                SUPPORTED_LANGUAGES.forEach { lang ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = lang.displayName,
                                                    fontWeight = if (lang.code == settings.ttsLanguageCode) FontWeight.Bold else FontWeight.Normal
                                                )
                                                if (lang.code == settings.ttsLanguageCode) {
                                                    Spacer(modifier = Modifier.weight(1f))
                                                    Icon(
                                                        imageVector = Icons.Default.Star,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            viewModel.updateLanguage(lang.code)
                                            languageExpanded = false
                                        },
                                        modifier = Modifier.testTag("lang_option_${lang.code}")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Whitelist / VIP Contacts Filter Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "VIP Contacts Whitelist",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Prevent interruptions from unknown or telemarketing numbers",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = settings.isWhitelistEnabled,
                                onCheckedChange = { viewModel.toggleWhitelistMode(it) },
                                modifier = Modifier.testTag("whitelist_switch")
                            )
                        }

                        if (settings.isWhitelistEnabled) {
                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Only callers matching the contacts below will be announced aloud:",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = newWhitelistContactText,
                                    onValueChange = { newWhitelistContactText = it },
                                    label = { Text("Contact Name or Phone") },
                                    placeholder = { Text("e.g. Rahul, Boss, +91 987...") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("add_whitelist_input")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (newWhitelistContactText.isNotBlank()) {
                                            viewModel.addWhitelistContact(newWhitelistContactText)
                                            newWhitelistContactText = ""
                                        }
                                    },
                                    modifier = Modifier.height(56.dp).testTag("add_whitelist_btn"),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Add contact")
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Whitelisted VIP List (${settings.whitelistedContacts.size})",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                settings.whitelistedContacts.forEach { contact ->
                                    InputChip(
                                        selected = true,
                                        onClick = {},
                                        label = { Text(contact) },
                                        trailingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Remove $contact from Whitelist",
                                                modifier = Modifier
                                                    .clickable {
                                                        viewModel.removeWhitelistContact(contact)
                                                    }
                                                    .padding(2.dp)
                                            )
                                        },
                                        colors = InputChipDefaults.inputChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Announcement Template Format Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Announcement Text Format",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Choose or edit how the contact name will be announced. Use {name} as placeholder.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        FORMAT_PRESETS.forEach { preset ->
                            FilterChip(
                                selected = templateText == preset,
                                onClick = {
                                    templateText = preset
                                    viewModel.updateSettings { it.copy(announcementTemplate = preset) }
                                },
                                label = { Text(preset) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = templateText,
                            onValueChange = {
                                templateText = it
                                viewModel.updateSettings { s -> s.copy(announcementTemplate = it) }
                            },
                            label = { Text("Custom Announcement Template") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("template_input"),
                            singleLine = true
                        )
                    }
                }
            }

            // Speech Rate & Pitch Sliders Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Speech Rate & Tone Pitch",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Speed Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speech Speed", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "${String.format("%.1f", settings.speechRate)}x",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = settings.speechRate,
                            onValueChange = { rate ->
                                viewModel.updateSettings { it.copy(speechRate = rate) }
                            },
                            valueRange = 0.5f..2.0f,
                            steps = 15,
                            modifier = Modifier.testTag("speech_rate_slider")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Pitch Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Voice Pitch", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "${String.format("%.1f", settings.speechPitch)}x",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = settings.speechPitch,
                            onValueChange = { pitch ->
                                viewModel.updateSettings { it.copy(speechPitch = pitch) }
                            },
                            valueRange = 0.5f..2.0f,
                            steps = 15,
                            modifier = Modifier.testTag("speech_pitch_slider")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Volume Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speech Volume", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "${(settings.speechVolume * 100).toInt()}%",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = settings.speechVolume,
                            onValueChange = { vol ->
                                viewModel.updateSettings { it.copy(speechVolume = vol) }
                            },
                            valueRange = 0.1f..1.0f,
                            steps = 9,
                            modifier = Modifier.testTag("speech_volume_slider")
                        )
                    }
                }
            }

            // Repeat & Delay Options
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Repeat,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Repetitions & Delay",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Announcement Repeat Count:", style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1, 2, 3, 5).forEach { count ->
                                FilterChip(
                                    selected = settings.repeatCount == count,
                                    onClick = {
                                        viewModel.updateSettings { it.copy(repeatCount = count) }
                                    },
                                    label = { Text("${count}x") }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Initial Delay Before Speaking:", style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0, 1, 2, 3).forEach { delaySec ->
                                FilterChip(
                                    selected = settings.delaySeconds == delaySec,
                                    onClick = {
                                        viewModel.updateSettings { it.copy(delaySeconds = delaySec) }
                                    },
                                    label = { Text("${delaySec} sec") }
                                )
                            }
                        }
                    }
                }
            }

            // Other Switches (Unknown callers, silent mode)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Announce Unknown Callers", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("Speak 'Unknown number is calling' when number is not in contacts", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = settings.announceUnknownNumbers,
                                onCheckedChange = { checked ->
                                    viewModel.updateSettings { it.copy(announceUnknownNumbers = checked) }
                                },
                                modifier = Modifier.testTag("unknown_caller_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Announce in Silent/Vibrate Mode", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("Overrides phone silent mode to announce caller names aloud", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = settings.announceInSilentMode,
                                onCheckedChange = { checked ->
                                    viewModel.updateSettings { it.copy(announceInSilentMode = checked) }
                                },
                                modifier = Modifier.testTag("silent_mode_switch")
                            )
                        }
                    }
                }
            }

            // Test Voice Action Button
            item {
                Button(
                    onClick = { viewModel.testTtsPreview() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("preview_tts_btn"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Test Voice Preview Now")
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}
