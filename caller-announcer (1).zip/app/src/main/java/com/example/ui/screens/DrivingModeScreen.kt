package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.PhoneDisabled
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.AmberDriving
import com.example.ui.viewmodel.MainViewModel

val QUICK_REPLY_PRESETS = listOf(
    "I am currently driving. I'll call you back shortly.",
    "In a meeting right now. Please leave a text message.",
    "Currently busy. Will call back as soon as possible."
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrivingModeScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var smsTextState by remember(settings.quickReplyMessage) { mutableStateOf(settings.quickReplyMessage) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Driving & Busy Mode",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Big Driving Mode Master Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (settings.isDrivingModeEnabled) AmberDriving else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(
                                            color = if (settings.isDrivingModeEnabled) Color.White else MaterialTheme.colorScheme.surface,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsCar,
                                        contentDescription = null,
                                        tint = if (settings.isDrivingModeEnabled) AmberDriving else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = if (settings.isDrivingModeEnabled) "Driving Mode ACTIVE" else "Driving Mode OFF",
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = if (settings.isDrivingModeEnabled) Color.Black else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (settings.isDrivingModeEnabled) "Hands-Free Voice & Auto Quick Reply" else "Tap switch to enable hands-free safety",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (settings.isDrivingModeEnabled) Color.Black.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Large Master Switch Button for Driver Ergonomics
                        Button(
                            onClick = { viewModel.toggleDrivingMode(!settings.isDrivingModeEnabled) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (settings.isDrivingModeEnabled) Color.Black else AmberDriving,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("driving_mode_master_btn")
                        ) {
                            Icon(Icons.Default.DirectionsCar, contentDescription = null)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (settings.isDrivingModeEnabled) "Turn OFF Driving Mode" else "Turn ON Driving Mode",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            // Auto SMS Quick Reply Toggle Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Message,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = "Auto Quick Reply SMS",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Send SMS automatically when a call arrives during driving",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = settings.autoSmsInDrivingMode,
                                onCheckedChange = { checked ->
                                    viewModel.updateSettings { it.copy(autoSmsInDrivingMode = checked) }
                                },
                                modifier = Modifier.testTag("auto_sms_switch")
                            )
                        }

                        if (settings.autoSmsInDrivingMode) {
                            Spacer(modifier = Modifier.height(16.dp))

                            Text("Preset Messages:", style = MaterialTheme.typography.labelLarge)
                            Spacer(modifier = Modifier.height(6.dp))

                            QUICK_REPLY_PRESETS.forEach { preset ->
                                FilterChip(
                                    selected = smsTextState == preset,
                                    onClick = {
                                        smsTextState = preset
                                        viewModel.updateSettings { it.copy(quickReplyMessage = preset) }
                                    },
                                    label = { Text(preset) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = smsTextState,
                                onValueChange = {
                                    smsTextState = it
                                    viewModel.updateSettings { s -> s.copy(quickReplyMessage = it) }
                                },
                                label = { Text("Custom Quick Reply SMS Text") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sms_text_input"),
                                maxLines = 3
                            )
                        }
                    }
                }
            }

            // Auto Reject Call Toggle Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneDisabled,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "Auto Reject Incoming Calls",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Automatically decline incoming calls while driving mode is enabled",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = settings.autoRejectInDrivingMode,
                            onCheckedChange = { checked ->
                                viewModel.updateSettings { it.copy(autoRejectInDrivingMode = checked) }
                            },
                            modifier = Modifier.testTag("auto_reject_switch")
                        )
                    }
                }
            }

            // Simulator Test Driver Auto Reply
            item {
                Button(
                    onClick = {
                        viewModel.simulateIncomingCall(
                            callerName = "Rahul",
                            phoneNumber = "+91 98765 43210",
                            isContactFound = true
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("test_driving_simulation_btn"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Test Driving Call Announcement & SMS")
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}
