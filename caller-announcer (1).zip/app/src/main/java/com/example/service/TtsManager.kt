package com.example.service

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _ttsStatus = MutableStateFlow("Initializing TTS...")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.getDefault())
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to US English if default locale isn't installed
                tts?.language = Locale.US
            }
            isInitialized = true
            _ttsStatus.value = "TTS Engine Ready (${Locale.getDefault().displayLanguage})"

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                }
            })
        } else {
            isInitialized = false
            _ttsStatus.value = "TTS Initialization Failed"
            Log.e("TtsManager", "TTS initialization failed with code $status")
        }
    }

    fun setLanguage(languageCode: String) {
        if (!isInitialized || tts == null) return
        val locale = parseLocale(languageCode)
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.US
            _ttsStatus.value = "TTS Engine Ready (Fallback: English US)"
        } else {
            _ttsStatus.value = "TTS Engine Ready (${locale.displayLanguage})"
        }
    }

    private fun parseLocale(languageCode: String): Locale {
        val parts = languageCode.split("_", "-")
        return when {
            parts.size >= 2 -> Locale(parts[0], parts[1])
            parts.size == 1 -> Locale(parts[0])
            else -> Locale.US
        }
    }

    fun speak(
        text: String,
        speechRate: Float = 1.0f,
        speechPitch: Float = 1.0f,
        speechVolume: Float = 1.0f,
        repeatCount: Int = 1,
        delayMs: Long = 500,
        languageCode: String? = null
    ) {
        if (!isInitialized || tts == null) {
            Log.w("TtsManager", "TTS not initialized yet")
            return
        }

        stop()

        if (languageCode != null) {
            setLanguage(languageCode)
        }

        tts?.setSpeechRate(speechRate)
        tts?.setPitch(speechPitch)

        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume)
        }

        val utteranceId = "CallerAnnouncerUtterance_${System.currentTimeMillis()}"

        // Speak for the configured number of repetitions
        for (i in 0 until repeatCount) {
            val queueMode = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            if (i > 0 && delayMs > 0) {
                tts?.playSilentUtterance(delayMs, TextToSpeech.QUEUE_ADD, "Silence_$i")
            }
            tts?.speak(text, queueMode, params, "${utteranceId}_$i")
        }
    }

    fun stop() {
        if (isInitialized && tts != null) {
            tts?.stop()
            _isSpeaking.value = false
        }
    }

    fun shutdown() {
        if (tts != null) {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isInitialized = false
        }
    }
}
