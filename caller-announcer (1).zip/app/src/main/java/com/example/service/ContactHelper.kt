package com.example.service

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log

object ContactHelper {

    /**
     * Resolves caller display name from stored phone contacts using ContactsContract.PhoneLookup.
     * Returns pair of (DisplayName or null if not found, boolean isFound)
     */
    fun getContactName(context: Context, phoneNumber: String?): Pair<String, Boolean> {
        if (phoneNumber.isNull_or_blank()) {
            return Pair("Unknown Number", false)
        }

        try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber)
            )
            val projection = arrayOf(
                ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.PhoneLookup._ID
            )

            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) {
                            return Pair(name, true)
                        }
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e("ContactHelper", "Permission READ_CONTACTS missing", e)
        } catch (e: Exception) {
            Log.e("ContactHelper", "Error querying contacts", e)
        }

        // Return clean formatted phone number if contact not found
        return Pair(formatNumberForSpeech(phoneNumber ?: "Unknown Number"), false)
    }

    private fun String?.isNull_or_blank(): Boolean {
        return this == null || this.trim().isEmpty()
    }

    /**
     * Formats raw phone digits for cleaner TTS pronunciation when contact is unknown.
     * E.g. "+19876543210" -> "9 8 7, 6 5 4, 3 2 1 0" or "Unknown caller"
     */
    fun formatNumberForSpeech(number: String): String {
        val clean = number.replace(Regex("[^0-9]"), "")
        return if (clean.length >= 7) {
            clean.chunked(3).joinToString(" ")
        } else if (clean.isNotEmpty()) {
            clean.toCharArray().joinToString(" ")
        } else {
            "Unknown Number"
        }
    }
}
