package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.Log
import com.example.data.db.AppDatabase
import com.example.data.model.AnnouncedCall
import com.example.data.preferences.AppPreferencesRepository
import com.example.data.repository.CallHistoryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CallAnnouncerReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        if (state == TelephonyManager.EXTRA_STATE_RINGING) {
            val prefsRepo = AppPreferencesRepository(context)
            val settings = prefsRepo.settings.value

            if (!settings.isAnnouncerEnabled) {
                Log.d("CallAnnouncerReceiver", "Announcer is disabled")
                return
            }

            // Lookup caller contact name
            val (callerName, isContactFound) = ContactHelper.getContactName(context, incomingNumber)

            // Whitelist verification logic
            if (settings.isWhitelistEnabled) {
                val cleanIncoming = incomingNumber?.replace(Regex("[^0-9+]"), "") ?: ""
                val isWhitelisted = settings.whitelistedContacts.any { entry ->
                    val cleanEntry = entry.replace(Regex("[^0-9+]"), "")
                    (cleanEntry.isNotEmpty() && cleanIncoming.endsWith(cleanEntry)) ||
                            callerName.contains(entry, ignoreCase = true) ||
                            entry.contains(callerName, ignoreCase = true)
                }

                if (!isWhitelisted) {
                    Log.d("CallAnnouncerReceiver", "Caller $callerName ($incomingNumber) is not in Whitelist. Skipping announcement.")
                    
                    // Log call as blocked by Whitelist in database
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val db = AppDatabase.getDatabase(context)
                            val repository = CallHistoryRepository(db.callHistoryDao())
                            repository.logCall(
                                AnnouncedCall(
                                    callerName = callerName,
                                    phoneNumber = incomingNumber ?: "Unknown",
                                    announcedText = "Blocked by Whitelist Filter",
                                    isContactFound = isContactFound,
                                    actionTaken = "Blocked (Not in Whitelist)",
                                    isSimulated = false
                                )
                            )
                        } catch (e: Exception) {
                            Log.e("CallAnnouncerReceiver", "Error saving call history", e)
                        }
                    }
                    return
                }
            }

            if (!isContactFound && !settings.announceUnknownNumbers) {
                Log.d("CallAnnouncerReceiver", "Unknown caller announcement disabled")
                return
            }

            // Construct text announcement based on template
            val announcedText = settings.announcementTemplate.replace("{name}", callerName)

            // Trigger TTS speech
            val ttsManager = TtsManager(context)
            ttsManager.speak(
                text = announcedText,
                speechRate = settings.speechRate,
                speechPitch = settings.speechPitch,
                speechVolume = settings.speechVolume,
                repeatCount = settings.repeatCount,
                delayMs = settings.delaySeconds * 1000L,
                languageCode = settings.ttsLanguageCode
            )

            var actionTaken = "Announced"

            // Auto-Reply SMS in Driving Mode
            if (settings.isDrivingModeEnabled && settings.autoSmsInDrivingMode && !incomingNumber.isNullOrBlank()) {
                try {
                    val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        context.getSystemService(SmsManager::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        SmsManager.getDefault()
                    }
                    smsManager.sendTextMessage(incomingNumber, null, settings.quickReplyMessage, null, null)
                    actionTaken = "Quick SMS Sent & Announced"
                } catch (e: Exception) {
                    Log.e("CallAnnouncerReceiver", "Failed to auto-send SMS reply", e)
                }
            }

            // Log call into database
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getDatabase(context)
                    val repository = CallHistoryRepository(db.callHistoryDao())
                    repository.logCall(
                        AnnouncedCall(
                            callerName = callerName,
                            phoneNumber = incomingNumber ?: "Unknown",
                            announcedText = announcedText,
                            isContactFound = isContactFound,
                            actionTaken = actionTaken,
                            isSimulated = false
                        )
                    )
                } catch (e: Exception) {
                    Log.e("CallAnnouncerReceiver", "Error saving call history", e)
                }
            }
        }
    }
}
